LabVNC beta release 0.4
(c) 2001 Jeffrey Travis, Graeme Cloughley, Scott Gerlach


0. INTRODUCTION
----------------
Welcome to LabVNC!

LabVNC allows you to painlessly and instantly enable web control of your VIs.
LabVNC will create a Java applet on the fly that is an exact representation 
of any VI you choose. This Java applet will run in a remote client browser
and will give them full control of your VI, just as if they were at your desktop.

LabVNC is based on the VNC (Virtual Network Computing) protocol. LabVNC is offered
under the terms of the GPL (GNU Public License); please read the attached license
terms.

For questions, bugs, comments, please email labvnc@jeffreytravis.com

For commercial technical support packages, contact labvnc@rayodyne.com


1. INSTALLATION
---------------

1a. System Requirements:
-----------------------
LabVNC consists of a VI control panel, some DLLs, and a binary executable that is the
LabVNC server. Currently the server only runs on 32-bit Windows. You must have LabVIEW 6.0
or greater installed on the server machine.

The remote clients can be on any platform for which there is a Java-enabled browser (Linux, MacOS, etc.)
We plan on soon providing LabVNC servers for the Linux and MacOS platform.

1b. Setup
----------------
1. To install LabVNC on the server, just unzip the labvnc.zip file into any directory. 
2. IMPORTANT:  Before you use LabVNC the very first time, you need to set a password for remote clients. 
To do so, run thebatch file "install.bat"  which is in the labnvc.lib directory. In the panel that
pops up, type a password (it cannot be blank). Hit OK.


The client does not need anything special, except any recent Java-enabled web browser
(e.g, Internet Explorer 5). 

NOTE: You cannot run a client on the same machine as the server. To test and run VNC,
you must be using 2 or more separate networked machines.



2. RUNNING LABVNC
-----------------

To use LabVNC server, follow these steps:

 1. If you haven't already, open the VI that you wish to share with remote web clients.
 2. Run the LabVNC.vi control panel.
 3. Under "Allow remote connections to:", select your VI
 4. Switch "LabVNC Server" to "on". After a few seconds, you should see a tray icon in the
 Windows tray showing the LabVNC Server is running. 
 5. The first time you run this server, you will need to set a password for your clients.
 To set a password, right click in the tray icon (not the VI), choose "Properties", and
 enter the remote password your web clients must supply to connect.
 6.Your server is now ready to accept remote connections
 
 To use the remote LabVNC web client:
 
 1. Open your browser (on a *different* machine than the server), and point your URL to:
    http://<machine name or IP address of server>:5800/
    
 2. You will be prompted for a password.
 
 3. You should see the VI in your web browser. You can control it now!
 
 

3. NOTES
---------

When you want to switch to a different VI to share, you must stop the LabVNC server
by switching to "off", selecting a new VI, and turning the server back on again.


4. TECHNICAL SUPPORT
--------------------

No formal technical support is offered on this beta version; however, you may contact
LabVNC's authors with your bugs and comments at"

 Jeffrey Travis <labvnc@jeffreytravis.com>
 Graeme Cloughley <graeme@rayodyne.com>
 
 You can also request the source code for LabVNC, by emailing us at the above address.
 
 You can purchase a variety of commercial support and maintenance agreements through
 Rayodyne LLC. For more information, please visit: http://rayodyne.com

Finally, if you are interested in contributing to LabVNC or just want to play with many of the advanced registry settings, such as IP blocking, etc., please visit the VNC website at http://www.research.att.
 

 
 
