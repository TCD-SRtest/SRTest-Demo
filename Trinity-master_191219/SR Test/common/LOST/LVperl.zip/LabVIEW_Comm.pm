package LabVIEW_Comm;
{
###############################################################################
#
# DESCRIPTION:
# This package encloses the subroutines necessary for communication with LabVIEW:
#
#  Open_LV_Connection([$port,$timeout]);
#    returns a filehandle that can be used with "print" statements to send data
#    from Perl to LabVIEW and vice-versa. Should be used with "Open Perl Connection.vi"
#    Global filehandle is $labview that is used by the other routines.
#  
#  Write_LV($command_name);
#    Sends LabVIEW the string $str.
#    Returns a value of 1 if successful, 0 if there was an error.
#
#  Read_LV();
#    Reads a string sent from LabVIEW.  Interpreting this string will depend on the context.
#    Returns the value read from Labview.
#
#  Close_LV_Connection();
#    Closes the TCP connection. 
# 
###############################################################################

# Stuff required for package exporting its subs and variables
#require     Exporter;
#@ISA        = qw(Exporter);
#@EXPORT     = qw( Open_LV_Connection
#                  Write_LV
#                  Read_LV
#                  Close_LV_Connection
#                  $labview,$text);
#@EXPORT_OK  = qw();



sub Open_LV_Connection
{
    use IO::Socket;
    use Net::hostent;               # for OO version of gethostbyaddr
    # Set up the server object

    $PORT = 9000;
    $timeout = 50000;
    
    $server = IO::Socket::INET->new(    Proto     => 'tcp',
                                        LocalPort => $PORT,
                                        Listen    => SOMAXCONN,
                                        Reuse     => 1,
                                        Timeout   => $timeout);

    die "can't setup TCP server" unless $server;
    
    # To reduce the size of the STDOUT file, only report every tenth connection.
    if ( (($Connect_Count) % 10) == 0 )
    {
        printf "Server port: $PORT Timeout value: $timeout Connect count: $Connect_Count\n";
    }
    
    # Now set up a client filehandle, $labview. This will be a global used in other places
    $labview = $server->accept(); 
    
    $labview->autoflush(1);

    # To reduce the size of the STDOUT file, only report every tenth connection.
    if ( (($Connect_Count++) % 10) == 0 )
    {
        printf "LabVIEW connected \n";
    }
    return $labview;
    
}


sub Close_LV_Connection() 
{
    close($labview);
}

sub Write_LV
{ 
    if ($labview) 
    {
        print $labview ($_[0]);      # Send command     
        print $labview "\r\n";       # print terminator
        while (<$labview>) 	     # Check for response
        {            
            next unless /\S/;        # ignore blank lines
		print "stuff was $_\n";
            if (/OK/i) 
            {
                return 1;
		print "OK\n";
            }
            else 
            {
                return 0;
            }
        }
    } 
    else 
    {
        return 0;
    }
    
}


sub Read_LV() 
{
    while (<$labview>) 
    {
        next unless /\S/;             # ignore blank lines
        return $_;
    }
}

return 1;

}