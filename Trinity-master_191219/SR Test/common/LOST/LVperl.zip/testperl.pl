use LabVIEW_Comm;

$PORT = 9000;
$timeout = 50000;
$labview = LabVIEW_Comm::Open_LV_Connection;
$_='';
until (/exit/) {

 $str = LabVIEW_Comm::Read_LV();

 print "***$str***\n";
 sleep(5);

 LabVIEW_Comm::Write_LV(' We git it buddy');

 #print $labview " We got it man\r\n";

 $_ = $str;

}

LabVIEW_Comm::Close_LV_Connection;